<?php

/**
 * Class SubstitutionEncodingAlgorithm
 *  http://www.writephponline.com/
 */
class SubstitutionEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * @var array
     */
    private $substitutions;

    /**
     * SubstitutionEncodingAlgorithm constructor.
     * @param $substitutions
     */
    public function __construct(array $substitutions)
    {
        $this->substitutions = $substitutions;
    }

    /**
     * Encodes text by substituting character with another one provided in the pair.
     * For example pair "ab" defines all "a" chars will be replaced with "b" and all "b" chars will be replaced with "a"
     * Examples:
     *      substitutions = ["ab"], input = "aabbcc", output = "bbaacc"
     *      substitutions = ["ab", "cd"], input = "adam", output = "bcbm"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */

        $uppercase = false; //pointer
		// check if text is uppercase (if its lower it for tests then up it again)
		if (strtoupper($text) == $text) 
		{
			$text = strtolower($text);
			$uppercase = true;
		}

		$sizeOfString = strlen($text);
		foreach ($this->substitutions as $substitution)
		{
			for ($j =0 ; $j < $sizeOfString ; $j++)
			{
				if ($substitution[0]== $text[$j])
				{
					$text[$j] = $substitution[1];
				} 
				else if ($substitution[1]== $text{$j})
				{
					$text[$j] = $substitution[0];
				}
			}
		}
		if ($uppercase === true) {
		$text = strtoupper($text);
		}
    	return $text;
    }
}