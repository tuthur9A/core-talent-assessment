<?php

/**
 * Class OffsetEncodingAlgorithm
 */
class OffsetEncodingAlgorithm implements EncodingAlgorithm
{
    /**
     * Lookup string
     */
    const CHARACTERS = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';

    /**
     * @var int
     */
    private $offset;

    /**
     * @param int $offset
     */
    public function __construct($offset = 13)
    {
        $this->offset = $offset;
    }

    /**
     * Encodes text by shifting each character (existing in the lookup string) by an offset (provided in the constructor)
     * Examples:
     *      offset = 1, input = "a", output = "b"
     *      offset = 2, input = "z", output = "B"
     *      offset = 1, input = "Z", output = "a"
     *
     * @param string $text
     * @return string
     */
    public function encode($text)
    {
        /**
         * @TODO: Implement it
         */
        $array_of_chars = str_split(self::CHARACTERS);
        for ($i=0;$i<strlen($text);$i++)
        {
            $key = array_search($text[$i],$array_of_chars);
            if ($key === 0 || $key <> false) 
            {
            $key += $this-> offset;
                if ($key > 51) {
                    $key -= 52;
                }
            $text[$i] = $array_of_chars[$key];
            }
           
        }
        return $text;
    }
}